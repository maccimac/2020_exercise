// set up mongoose
let mongoose = require('mongoose'),
    Schema = mongoose.Schema;

